export default function CoursesPage() {
  return <h1>Courses Page</h1>;
}
