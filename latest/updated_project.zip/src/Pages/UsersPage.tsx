export default function UsersPage() {
  return <h1>Users Page</h1>;
}
